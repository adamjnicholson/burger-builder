const auxi = props => props.children;

export default auxi;